IPC Daily Round App
====================
A mobile-friendly Infection Prevention & Control daily hospital round app.

Features:
- Daily round details
- 20-point IPC checklist
- Compliant / Partial / Non-compliant / N/A
- Automatic compliance score
- Corrective action and follow-up fields
- Dashboard
- Round history and search
- Data saved in browser localStorage

How to use:
1. Open index.html in Chrome/Edge.
2. On Android, use browser menu -> Add to Home Screen.
3. Data is stored on that device/browser.

Important:
This first version is an offline prototype. It does not yet have cloud sharing, user login, photo upload, Excel/PDF export, or a central hospital database.
